const mongoose = require('mongoose');

// Replace with your MongoDB URI
const mongoURI = "mongodb://localhost:27017/corenotes";

const CTM = async () => {
    try {
        await mongoose.connect(mongoURI, { 
            useNewUrlParser: true, 
            useUnifiedTopology: true 
        });
        console.log("Connected to MongoDB");
    } catch (error) {
        console.error("Error connecting to MongoDB:", error);
    }
};

module.exports = CTM;
