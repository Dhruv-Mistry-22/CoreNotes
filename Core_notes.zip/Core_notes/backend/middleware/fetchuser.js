const jwt = require("jsonwebtoken");
const JWT_TOKEN = "CEO";

const fetchusers = (req, res, next) => {
  const token = req.header("auth-token");
  if (!token) {
    return res.status(401).send({ error: "Please authenticate." });
  }
  try {
    const Data = jwt.verify(token, JWT_TOKEN);
    req.user = Data.user;
    next();
  } catch (error) {
    return res.status(401).send({ error: "Please authenticate." });
  }
};
module.exports = fetchusers;
