const express = require("express");
const router = express.Router();
const { body, validationResult } = require("express-validator");
const bcrypt=require("bcryptjs");
const jwt=require("jsonwebtoken");
const fetchusers=require('../middleware/fetchuser');

const JWT_TOKEN='CEO';

const User = require("../models/User");

router.post(
  "/cretaeuser",
  [
    body("name").isLength({ min: 3 }),
    body("password").isLength({ min: 3 }),
    body("email").isEmail(),
  ],

  async (req, res) => {
    let success=false;
    const error = validationResult(req);
    if (!error.isEmpty()) {
      return res.status(400).json({ success,error: error.array() });
    }
    try {
      let user = await User.findOne({ email: req.body.email });
      if (user) {
        return res.status(400).json({ success,error: "Email already exists" });
      }
      const salt = await bcrypt.genSalt(10);
      let SecPass=  await bcrypt.hash(req.body.password,salt);

      user = await User.create({
        name: req.body.name,
        password: SecPass,
        email: req.body.email,
      });

      const data={
        user:{
        id:user.id,}
      }

      const auttoken=jwt.sign(data,JWT_TOKEN);
        success=true;
      res.json({success,auttoken});
    } catch (error) {
      console.error(error.message);
      res.status(500).send("Something Is Wrong");
    }
  }
);

router.post(
  "/login",
  [
    body("password").isLength({ min: 3 }),
    body("email").isEmail(),
  ],

  async (req, res) => {
    const error = validationResult(req);
    if (!error.isEmpty()) {
      return res.status(400).json({ Status:"False",error: error.array() });
    }
    const{email,password}=req.body;
    try {
      let user = await User.findOne({email});
      if (!user) {
        return res.status(400).json({Status:"False", error: "Please insert correct information" });
      }
       
      const passwordcompare= await bcrypt.compare(password,user.password);

      if(!passwordcompare){
        return res.status(400).json({Status:"False", error: "Please insert correct information" });
       
      }

      const data={
        user:{
        id:user.id,}
      }

      const auttoken=jwt.sign(data,JWT_TOKEN);

      res.json({Status:"True",auttoken});
    } catch (error) {
      console.error(error.message);
      res.status(500).send("Something Is Wrong");
    }
  }
);

router.post(
  "/getuser",fetchusers,
   
  async (req, res) => {
    
    try {
      userid=req.user.id;
      const user=await User.findById(userid).select("-password")
      res.send(user)
    } catch (error) {
      console.error(error.message);
      res.status(500).send("Something Is Wrong");
    }
  }
);


module.exports = router;
