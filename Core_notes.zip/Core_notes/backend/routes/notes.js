const express = require("express");
const router = express.Router();
const fetchusers = require("../middleware/fetchuser");
const Notes = require("../models/Notes");
const { body, validationResult } = require("express-validator");

router.get("/fetchallnotes", fetchusers, async (req, res) => {
  try {
    const notes = await Notes.find({ user: req.user.id });
    res.json(notes);
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Internal  Server Error ");
  }
});

router.post(
  "/addnotes",
  fetchusers,
  [body("title").isLength({ min: 3 }), body("document").isLength({ min: 3 })],
  async (req, res) => {
    try {
      const error = validationResult(req);
      if (!error.isEmpty()) {
        return res.status(400).json({ error: error.array() });
      }
      const { title, document, tag } = req.body;

      const notes = new Notes({ title, document, tag, user: req.user.id });
      const savenote = await notes.save();
      res.json(savenote);
    } catch (error) {
      console.error(error.message);
      res.status(500).send("Internal  Server Error ");
    }
  }
);

router.put("/updatenotes/:id", fetchusers, async (req, res) => {
  try {
    const { title, document, tag } = req.body;

    const id = req.params.id;
    let SaveNotes = {};
    if (req.body.title) {
      SaveNotes.title = title;
    }
    if (req.body.document) {
      SaveNotes.document = document;
    }
    if (req.body.tag) {
      SaveNotes.tag = tag;
    }

    let note = await Notes.findById(req.params.id);
    if (!note) {
      return res.status(404).json({ msg: "Note Not Found" });
    }
    if (note.user.toString() !== req.user.id) {
      return res.status(401).json({ msg: "Not Allowed" });
    }
    note = await Notes.findByIdAndUpdate(
      id,
      { $set: SaveNotes },
      { new: true }
    );
    res.json(note);
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Internal  Server Error ");
  }
});

router.delete("/deletenotes/:id", fetchusers, async (req, res) => {
  try {

    const id = req.params.id;
   

    let note = await Notes.findById(req.params.id);
    if (!note) {
      return res.status(404).json({ msg: "Note Not Found" });
    }
    if (note.user.toString() !== req.user.id) {
      return res.status(401).json({ msg: "Not Allowed" });
    }
    note = await Notes.findByIdAndDelete(id);
    res.json({"Note":"Deleted"});
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Internal  Server Error ");
  }
});
module.exports = router;