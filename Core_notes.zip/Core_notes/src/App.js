import React,{useState} from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./Component/Navbar";
import Home from "./Component/Home";
import About from "./Component/About";
import NoteState from "./Context/NoteState";
import Login from "./Component/Login";
import Singnup from "./Component/Signup";
import Alert from "./Component/Alert";
import './App.css';
const App = () => {
  const [salert, setalert] = useState(null);

  const showalert = (type) => {
    setalert(type);
    setTimeout(() => {
      setalert(null);
    }, 3000);
  };

  return (
    <NoteState>
      <Router>
      <div className="app-container">

        <Navbar />
        <Alert salert={salert}/>
        <Routes>
          <Route exact path="/" element={<Home showalert={showalert}/>} />
          <Route exact path="/About" element={<About />} />
          <Route exact path="/Login" element={<Login showalert={showalert}/>} />
          <Route exact path="/Signup" element={<Singnup showalert={showalert}/>} />
        </Routes>
        </div>
      </Router>
    </NoteState>
  );
};

export default App;
