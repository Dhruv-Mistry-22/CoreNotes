import React, { useState } from 'react';
import './Login.css'; // Use SignUp's CSS file for consistency
import { useNavigate } from 'react-router-dom';
import l from "./s.png";

const Login = (props) => {
    let navigate = useNavigate();
    const host = "http://localhost:5000";

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault(); // Prevent form refresh

        const url = `${host}/api/auth/login`;
        const response = await fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ email, password }), // Pass as an object
        });
        const json = await response.json();
        console.log(json);
        if (json.Status === "True") {
            localStorage.setItem('token', json.auttoken);
            console.log(localStorage.getItem('token'));

            props.showalert("Successfully Logged In");
            navigate("/");
        } else {
            console.log('Invalid credentials');
            props.showalert("Wrong Details");
        }
    };

    const handleChange = (e) => {
        const { name, value } = e.target; // Destructure the name and value of the input
        if (name === "email") {
            setEmail(value);
        } else if (name === "password") {
            setPassword(value);
        }
    };

    return (
        <div className="login-container"> {/* Reuse the same class name from SignUp */}
            <div className="form-section"> {/* Reuse the same class name from SignUp */}
                <h1>Login</h1>
                <form onSubmit={handleSubmit} className="signup-form"> {/* Reuse the form styles from SignUp */}
                    <input
                        type="email"
                        id="email"
                        name="email"
                        value={email}
                        onChange={handleChange}
                        placeholder="Email"
                        required
                    />
                    <input
                        type="password"
                        id="password"
                        name="password"
                        value={password}
                        onChange={handleChange}
                        placeholder="Password"
                        required
                    />
                    <button type="submit" className="signup-button"> {/* Reuse the button class from SignUp */}
                        Login
                    </button>
                </form>
            </div>
            <div className="image-section"> {/* Reuse the same image section class */}
                <img src={l} alt="Login illustration"/>
            </div>
        </div>
    );
};

export default Login;
