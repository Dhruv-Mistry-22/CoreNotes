import React from "react";
import "./Alert.css";

const Alert = (props) => {
  return (
    <div className={`alert ${props.salert ? "show" : ""}`}>
      <strong>{props.salert}</strong>
    </div>
  );
};

export default Alert;
