import React from "react";
import { Link, useNavigate } from "react-router-dom";
import "./Navbar.css"; // Import the external CSS file

const Navbar = () => {
  let navigation = useNavigate();

  const handlelogout = () => {
    localStorage.removeItem("token");
    navigation("/login");
  };

  return (
    <nav className="navbar">
      <div className="navbar-logo">
        <Link to="/" className="navbar-brand">
          CoreNotes
        </Link>
      </div>
      <div className="navbar-links">
        {!localStorage.getItem("token") ? (
          <div className="navbar-links-right">
            <Link to="/Login" className="navbar-link">
              Login
            </Link>
            <Link to="/Signup" className="navbar-link">
              Sign-Up
            </Link>
          </div>
        ) : (
          <div className="navbar-links-right">
            <Link to="/" className="navbar-link">
              Home
            </Link>
            <Link to="/About" className="navbar-link">
              About
            </Link>
            <button className="logout-btn" onClick={handlelogout}>
              LogOut
            </button>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
