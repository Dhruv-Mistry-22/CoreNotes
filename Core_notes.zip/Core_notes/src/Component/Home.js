import React from "react";
import Note from "./Note";

function Home(props) {
  return (
    <div>
      <Note showalert={props.showalert}/>
      <footer style={{ textAlign: "center", marginTop: "20px", padding: "1px", backgroundColor: "white",color:"black" }}>
          <p>&copy; {new Date().getFullYear()} Innovsphere. All rights reserved.</p>
        </footer>
    </div>
  );
}

export default Home;
