import React, { Component } from 'react';
import corenotesLogo from './innovsphere_logo.png';


class About extends Component {
  render() {
    return (
      <div style={styles.container}>
        <div style={styles.content}>
          <h2 style={styles.heading}>About CoreNotes</h2>
          <p style={styles.text}>
            CoreNotes is your ultimate platform for creating, organizing, and sharing personal
            notes and study materials. Whether you're a student, a professional, or simply someone
            looking to keep track of ideas, CoreNotes helps you capture and manage your thoughts
            efficiently and securely.
          </p>

          <p style={styles.text}>
            With CoreNotes, you can easily create and categorize notes, add images and attachments,
            and share your work with others. Our goal is to make note-taking and information
            management easier than ever by offering a clean, user-friendly interface designed for
            productivity.
          </p>

          <p style={styles.text}>
            Powered by cloud technology, CoreNotes ensures that your notes are always accessible,
            no matter where you are. Whether you're on a mobile device, tablet, or desktop, you
            can seamlessly access your notes and continue working from any location.
          </p>

          <p style={styles.text}>
            CoreNotes is not just a note-taking app – it’s your digital notebook, designed to
            enhance your organization, boost your creativity, and help you stay productive. Join us
            in revolutionizing the way you take notes and stay organized.
          </p>
        </div>

        <div style={styles.innovsphereContainer}>
          <p style={styles.innovsphereText}>This website is powered by Innovsphere</p>
          <div style={styles.logoContainer}>
            <img src={corenotesLogo} alt="CoreNotes Logo" style={styles.logo} />
          </div>
        </div>
      </div>
    );
  }
}

const styles = {
  container: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    padding: '30px',
    backgroundColor: '#f4f4f9',
    minHeight: '100vh',
    justifyContent: 'center',
  },
  content: {
    textAlign: 'center',
    maxWidth: '900px',
    marginBottom: '30px',
  },
  heading: {
    fontSize: '36px',
    fontWeight: 'bold',
    color: '#333',
    marginBottom: '20px',
  },
  text: {
    fontSize: '18px',
    lineHeight: '1.6',
    color: '#555',
    marginBottom: '15px',
  },
  innovsphereContainer: {
    textAlign: 'center',
    marginTop: '30px',
  },
  innovsphereText: {
    fontSize: '16px',
    color: '#777',
    marginBottom: '10px',
  },
  logoContainer: {
    marginTop: '10px',
    display: 'flex',
    justifyContent: 'center',
    width: '100%',
  },
  logo: {
    width: '120px', // Adjust the size of the CoreNotes logo
    height: 'auto',
  },
};

export default About;
