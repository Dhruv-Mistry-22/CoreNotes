import React, { useContext, useEffect, useState } from "react";
import NoteContext from "../Context/noteContext";
import AddNote from "./AddNote";
import NoteItem from "./NoteItem";
import UpdateNoteModal from "./UpdateNoteModal";
import "./Note.css";
import { useNavigate } from "react-router-dom";

function Note(props) {
  let navigation = useNavigate();

  const Context = useContext(NoteContext);
  const { notes, getnotes, editnote } = Context;

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentNote, setCurrentNote] = useState({ title: "", document: "" }); // Ensure 'description' field here

  useEffect(() => {
    
    if (localStorage.getItem("token")) {
      getnotes();
    } else {
 
      navigation("/login");
    }
         // eslint-disable-next-line
  }, [getnotes]);

  const handleEditClick = (note) => {
    // console.log("Editing Note:", note); // Check if correct note is passed to the modal
    setCurrentNote(note);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  return (
    <>
      <AddNote showalert={props.showalert} />
      <h1 style={{ textAlign: "center", marginTop: "40px", color: "#006b3f" }}>
        Your Notes:
      </h1>
      {notes.length === 0 && (
  <div className="no-notes-message">No Notes to Display</div>
)}
      <div className="note-item-container">
        {notes.map((note, index) => (
          <div key={index} className="note-card">
            <NoteItem
              note={note}
              onEdit={handleEditClick}
              showalert={props.showalert}
            />
          </div>
        ))}
      </div>
      <UpdateNoteModal
        isOpen={isModalOpen}
        closeModal={closeModal}
        editnote={editnote}
        currentNote={currentNote}
        showalert={props.showalert}
      />
    </>
  );
}

export default Note;
