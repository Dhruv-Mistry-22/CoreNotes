import React, { useContext, useState } from "react";
import NoteContext from "../Context/noteContext";
import './Addnote.css';

function AddNote(props) {
  const Context = useContext(NoteContext);
  const { addnote } = Context;
  const [note, setnote] = useState({ title: "", Description: "" });

  const handleClick = (e) => {
    e.preventDefault();
    addnote(note.title, note.Description);
    props.showalert(" Added Successfully");

    setnote({ title: "", Description: "" });
  };

  const onchange = (e) => {
    setnote({ ...note, [e.target.name]: e.target.value });
  };

  return (
    <div className="addnote-container">
      <h1 className="addnote-title">Add A Note:</h1>
      <form className="addnote-form">
        <div>
          <label htmlFor="title" className="addnote-label">Title:</label>
          <input
            type="text"
            id="title"
            name="title"
            className="addnote-input"
            placeholder="Enter note title"
            value={note.title}
            onChange={onchange}
          />
        </div>
        <div>
          <label htmlFor="Description" className="addnote-label">Description:</label>
          <textarea
            id="content"
            name="Description"
            className="addnote-textarea"
            placeholder="Write your note here..."
            rows="4"
            value={note.Description}
            onChange={onchange}
          ></textarea>
        </div>
        <button
          className="addnote-button"
          disabled={note.title.length < 5 || note.Description.length < 5}
          type="submit"
          onClick={handleClick}
        >
          Add Note
        </button>
      </form>
    </div>
  );
}

export default AddNote;
