import React, { useState } from 'react';
import './SignUp.css'; // Import the external CSS file
import { useNavigate } from 'react-router-dom';
import ss from './s.png';

const SignUp = (props) => {
    let navigate = useNavigate();
    const host = "http://localhost:5000";

    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault(); // Prevent form refresh

        const url = `${host}/api/auth/cretaeuser`; // Corrected API endpoint URL
        const response = await fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ name, email, password }), // Send name, email, and password
        });
        const json = await response.json();
        console.log(json)
        if (json.success) {
            localStorage.setItem('token', json.auttoken);
            props.showalert("Successfully Signed Up!");  
            navigate("/"); // Navigate to home or login page after successful signup
        } else {
            console.log('Error: ', json.message);
            props.showalert("Something went wrong during Sign-Up");  
        }
    };

    const handleChange = (e) => {
        const { name, value } = e.target; // Destructure the name and value of the input
        if (name === "name") {
            setName(value);
            console.log("d1")
        } else if (name === "email") {
            setEmail(value);
            console.log("d1")

        } else if (name === "password") {
            setPassword(value);
            console.log("d1")

        }
    };

    return (
        <div className="signup-container">
            <div className="form-section">
                <h1>Create New Account</h1>
                <form onSubmit={handleSubmit} className="signup-form">
                    <input
                        type="text"
                        id="name"
                        name="name"
                        value={name}
                        onChange={handleChange}
                        placeholder="Name"
                        required
                    />
                    <input
                        type="email"
                        id="email"
                        name="email"
                        value={email}
                        onChange={handleChange}
                        placeholder="Email"
                        required
                    />
                    <input
                        type="password"
                        id="password"
                        name="password"
                        value={password}
                        onChange={handleChange}
                        placeholder="Password"
                        required
                    />
                    <button type="submit" className="signup-button">Create Account</button>
                </form>
            </div>
            <div className="image-section">
                <img src={ss} alt="Welcome illustration"/>
            </div>
        </div>
    );
};

export default SignUp;
