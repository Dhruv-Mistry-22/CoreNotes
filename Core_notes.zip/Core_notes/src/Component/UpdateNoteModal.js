import React, { useState, useEffect } from "react";
import "./UpdateNoteModal.css";

function UpdateNoteModal({ isOpen, closeModal, editnote, currentNote,showalert}) {
  // Assuming currentNote has title and description fields
  const [updatedTitle, setUpdatedTitle] = useState(currentNote.title || "");
  const [updatedDescription, setUpdatedDescription] = useState(
    currentNote.document || ""
  );

  // Update the modal fields when currentNote changes
  useEffect(() => {
    if (currentNote) {
      setUpdatedTitle(currentNote.title || "");
      setUpdatedDescription(currentNote.document || ""); // Ensure this is 'description'
    }
  }, [currentNote]);

  const handleSubmit = (e) => {
    e.preventDefault();
    showalert(" Updated SuccessFully "); 
    editnote(currentNote._id, updatedTitle, updatedDescription); // Pass updated title and description
     

    closeModal(); // Close the modal after submitting
  };

  if (!isOpen) return null;

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <h2>Update Note</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="title">Title:</label>
            <input
              id="title"
              value={updatedTitle}
              onChange={(e) => setUpdatedTitle(e.target.value)} // Update title state
              minLength={5}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="description">Description:</label>{" "}
            {/* Change to description */}
            <textarea
              id="description"
              value={updatedDescription}
              onChange={(e) => setUpdatedDescription(e.target.value)} // Update description state
            />
          </div>
          <div className="modal-buttons">
            <button className="up"
              disabled={
                updatedTitle.length < 5 || updatedDescription.length < 5
              }
              type="submit"
            >
              Update
            </button>
            <button className="ca"type="button" onClick={closeModal}>
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default UpdateNoteModal;
