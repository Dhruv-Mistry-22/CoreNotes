import React, { useContext, useState } from "react";
import NoteContext from "../Context/noteContext";
import "./NoteItem.css"; // Importing the CSS file

function NoteItem(props) {
  const Context = useContext(NoteContext);
  const { deletenote } = Context;
  const { note } = props;

  // State to control the visibility of the dropdown menu
  const [isDropdownVisible, setIsDropdownVisible] = useState(false);

  // Toggle the dropdown visibility
  const toggleDropdown = () => {
    setIsDropdownVisible(!isDropdownVisible);
  };

  return (
    <div className="note-card">
      {/* Note title */}
      <div className="note-title-container">
        <h3 className="note-title">{note.title}</h3>

        {/* Three-dot menu icon */}
        <i
          className="fa-solid fa-ellipsis-vertical"
          onClick={toggleDropdown}
          style={{ cursor: "pointer" }}
        ></i>

        {/* Dropdown menu */}
        {isDropdownVisible && (
          <div className="dropdown-menu">
            <div
              className="dropdown-item"
              onClick={() => {
                deletenote(note._id);
                props.showalert("Deleted Successfully");
                setIsDropdownVisible(false); // Close dropdown after delete
              }}
            >
            <i className="fa-solid fa-trash"></i>
            </div>
            <div
              className="dropdown-item"
              onClick={() => {
                props.onEdit(note);
                setIsDropdownVisible(false); // Close dropdown after update
              }}
            >
             <i className="fa-solid fa-pen"> </i>
            </div>
          </div>
        )}
      </div>

      {/* Note content */}
      <p className="note-content">{note.document}</p>
    </div>
  );
}

export default NoteItem;
