import React from "react";
import NoteContext from "./noteContext";
import { useState } from "react";

const NoteState = (props) => {
  const host = "http://localhost:5000";
  const noteitem = [];

  const [notes, setNotes] = useState(noteitem);

  const getnotes = async () => {
    const url = `${host}/api/notes/fetchallnotes`;
    const responce = await fetch(url, {
      method: "GET",
      headers: {
        "content-type": "application/json",
        "auth-token": localStorage.getItem("token"),
      },
    });
    const json = await responce.json();
    setNotes(json);
  };

  const addnote = async (title, Description, tag = "Personal") => {
    const url = `${host}/api/notes/addnotes`;
    const responce = await fetch(url, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "auth-token": localStorage.getItem("token"),
      },
      body: JSON.stringify({ title, document: Description, tag }),
    });
    // eslint-disable-next-line
    const note = await responce.json();

    if (note.title && note.document) {
      setNotes(notes.concat(note));
    }
  };

  const deletenote = async (id) => {
    const url = `${host}/api/notes/deletenotes/${id}`;
    const responce = await fetch(url, {
      method: "DELETE",
      headers: {
        "content-type": "application/json",
        "auth-token": localStorage.getItem("token"),
      },
    });
    // eslint-disable-next-line
    const json = await responce.json();

    const newnote = notes.filter((note) => {
      return note._id !== id;
    });
    setNotes(newnote);
  };

  const editnote = async (id, title, Description, tag = "Personal") => {
    const url = `${host}/api/notes/updatenotes/${id}`;
    const responce = await fetch(url, {
      method: "PUT",
      headers: {
        "content-type": "application/json",
        "auth-token": localStorage.getItem("token"),
      },
      body: JSON.stringify({ title, document: Description, tag }),
    });
    // eslint-disable-next-line
    const json = await responce.json();
    let newnote = JSON.parse(JSON.stringify(notes));

    for (let index = 0; index < newnote.length; index++) {
      const element = newnote[index];
      if (element._id === id) {
        newnote[index].title = title;
        newnote[index].document = Description;
        newnote[index].tag = tag;
        break;
      }
    }
    setNotes(newnote);
  };
  return (
    <NoteContext.Provider
      value={{ notes, addnote, deletenote, editnote, getnotes }}
    >
      {props.children}
    </NoteContext.Provider>
  );
};

export default NoteState;
